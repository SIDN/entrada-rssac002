import argparse
import asyncio
import datetime
import json
from pathlib import Path
from typing import Any

import yaml

from src.config.config_parser import Config
from src.querying.query_executors import QueryExecutor, SQLiteQueryExecutor
from src.run_unique_sources import parse_date


async def run_all_queries(
    query_executor: QueryExecutor,
    start: datetime.datetime,
    end: datetime.datetime,
    tld: str | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """Execute every query in the current query catalog for a single time range."""
    params = (start, end)
    tld_value = tld or query_executor.tld
    query_methods = {
        "rcode_volume_global": query_executor.query_rcode_volume_global,
        "rcode_volume_per_ns": query_executor.query_rcode_volume_per_ns,
        "unique_sources_global": query_executor.query_unique_sources_global,
        "unique_sources_per_ns": query_executor.query_unique_sources_per_ns,
        "traffic_volume_global": query_executor.query_traffic_volume_global,
        "traffic_volume_per_ns": query_executor.query_traffic_volume_per_ns,
        "traffic_sizes_global_request": query_executor.query_traffic_sizes_global_request,
        "traffic_sizes_per_ns_request": query_executor.query_traffic_sizes_per_ns_request,
        "traffic_sizes_global_response": query_executor.query_traffic_sizes_global_response,
        "traffic_sizes_per_ns_response": query_executor.query_traffic_sizes_per_ns_response,
    }

    results: dict[str, list[dict[str, Any]]] = {}
    for name, method in query_methods.items():
        results[name] = await method(params)

    if not tld_value:
        raise ValueError("A TLD value is required to run the query catalog.")

    return results


def build_executor(config_path: Path, tld: str | None, sqlite_mode: bool) -> QueryExecutor:
    if sqlite_mode:
        return SQLiteQueryExecutor(tld=tld or "example")

    with config_path.open() as config_file:
        config = Config.model_validate(yaml.safe_load(config_file))

    return config.query_executor.build(tld or config.tld_evaluated)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run every query in the configured query catalog for a date range.")
    parser.add_argument("--config", type=Path, default=Path("rssac002config.yaml"), help="YAML config file to use for Trino connection details.")
    parser.add_argument("--start", type=parse_date, required=True, help="First date to query, inclusive (YYYY-MM-DD)")
    parser.add_argument("--end", type=parse_date, required=True, help="Last date to query, inclusive (YYYY-MM-DD)")
    parser.add_argument("--tld", default=None, help="TLD to evaluate. Defaults to the config value or a SQLite fallback of 'example'.")
    parser.add_argument("--sqlite", action="store_true", help="Use the in-memory SQLite executor instead of the configured query engine.")
    args = parser.parse_args()

    if args.end < args.start:
        parser.error("--end must be on or after --start")

    tld_value = args.tld or ("example" if args.sqlite else None)
    executor = build_executor(args.config, tld_value, args.sqlite)

    start_dt = datetime.datetime.combine(args.start, datetime.time.min)
    end_dt = datetime.datetime.combine(args.end + datetime.timedelta(days=1), datetime.time.min)

    results = asyncio.run(run_all_queries(executor, start_dt, end_dt, tld_value or getattr(executor, "tld", None)))
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
